


from nltk.tokenize import word_tokenize
from nltk.corpus import stopwords
from collections import Counter
import string
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from RPA.core.notebook import notebook_print as np


def get_sentiment(input_1):
    #np(len(input_1))
    l=[]
    for i in input_1:
        text=i
        lower_case = text.lower()
        cleaned_text = lower_case.translate(str.maketrans('','',string.punctuation))
        tokenized_words= word_tokenize(cleaned_text,"english")
        final_words=[]

        for i in tokenized_words:
             if i not in stopwords.words('english'):
                    final_words.append(i)
        score=SentimentIntensityAnalyzer().polarity_scores(cleaned_text)
        neg = score['neg']
        pos=score['pos']
        if neg<pos:
            l.append('Positive')
        elif neg>pos:
            l.append('Negative')
        else:
            l.append('Neutral')
    d = Counter(l)
    p = d['Positive']
    n = d['Negative']
    ne = d['Neutral']
    if p>n:
        return  "Recommending"
    elif p<n:
        return  "Not Reccommending"
    else:
        return "Not sure"









